# Md Siddikur Rahman — Personal Portfolio Website

**Live Demo:** `https://[your-github-username].github.io/[repo-name]/`

A fully responsive, production-ready academic portfolio for **Md Siddikur Rahman** — Cybersecurity & Network Security Specialist, Adjunct Instructor at Pacific States University.

---

## ✨ Features

- Fully responsive (mobile, tablet, desktop)
- Dark hero with editorial light sections — distinctive split theme
- Scroll-reveal animations (IntersectionObserver)
- Animated skill progress bars on scroll
- Active nav highlighting per section
- Mobile hamburger navigation
- Contact form with feedback state
- GitHub Pages ready — zero build step required
- SEO meta tags and Open Graph markup

---

## 📁 Project Structure

```
portfolio/
├── index.html          # Complete single-page HTML
├── css/
│   └── style.css       # All styles — responsive, themed
├── js/
│   └── main.js         # Interactions, animations, form
├── assets/             # Create this folder for your images
│   ├── award-1.jpg     # Picture 2 — Excellence Award photo
│   └── award-2.jpg     # Picture 3 — IEEE Award photo
└── README.md
```

---

## 🚀 Deploy to GitHub Pages

### Step 1 — Create GitHub Repository

1. Visit [github.com](https://github.com) and sign in
2. Click **"New repository"**
3. Name it `portfolio` (or any name you prefer)
4. Set visibility to **Public**
5. Click **"Create repository"**

### Step 2 — Upload Files

**Option A — GitHub Web UI (easiest):**
1. Open your repository
2. Click **"uploading an existing file"**
3. Upload all files, preserving folder structure:
   - `index.html` (root)
   - `css/style.css`
   - `js/main.js`
   - `README.md`
4. Click **"Commit changes"**

**Option B — Git CLI:**
```bash
git init
git add .
git commit -m "Initial portfolio commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/portfolio.git
git push -u origin main
```

### Step 3 — Enable GitHub Pages

1. In your repo, click **Settings**
2. Left sidebar → **Pages**
3. Under **Source**, select:
   - Branch: `main`
   - Folder: `/ (root)`
4. Click **Save**
5. Wait 1–3 minutes, then visit:  
   `https://YOUR_USERNAME.github.io/portfolio/`

---

## 🖼️ Adding Award Photos (Picture 2 & 3)

1. Create an `assets/` folder in the project root
2. Add your award photos (JPG/PNG/WebP)
3. In `index.html`, find the `.aw-placeholder` div inside each `.aw-card` and replace it with:

```html
<img 
  src="assets/your-award-photo.jpg" 
  alt="Excellence in Academic Leadership Award 2023"
  style="width:100%;height:100%;object-fit:cover;" 
/>
```

---

## ✏️ Personalizing Content

All editable content is in `index.html`:

| What to change | Where to find it |
|---|---|
| Email address | Contact section, `href="mailto:..."` |
| LinkedIn URL | Contact section, `href="https://linkedin.com..."` |
| GitHub repo links | Each project card, `href="#"` placeholders |
| Publication details | Research section `.rl-item` cards |
| Event details | Events section `.et-item` entries |
| Award descriptions | Awards section `.aw-info` |

---

## 🎨 Customizing Colors

Open `css/style.css` and edit the `:root` variables:

```css
:root {
  --accent: #1e40af;        /* Main blue (buttons, links) */
  --accent-light: #3b82f6;  /* Lighter blue (highlights) */
  --teal: #0d9488;          /* Conference badge color */
  --amber: #d97706;         /* Award / featured color */
  --ink: #0f1623;           /* Dark hero background */
}
```

---

## 🔧 Tech Stack

- **HTML5** — Semantic markup, SEO meta, Open Graph
- **CSS3** — Custom properties, Grid, Flexbox, keyframe animations
- **Vanilla JS** — IntersectionObserver, smooth scroll, form handling
- **Google Fonts** — Space Grotesk + Crimson Pro + Fira Code

No frameworks. No build tools. Pure web standards.

---

## 📄 License

© 2025 Md Siddikur Rahman. All rights reserved.
